# Target Validation - Implementation

Detailed Python implementations for each workflow phase with proper error handling and fallback chains.

---

## Setup and Imports

```python
#!/usr/bin/env python3
"""
Target Validation Pipeline - Python SDK Implementation
Comprehensive target assessment from biological intelligence to validation decisions.
"""

from datetime import datetime
from typing import Dict, List, Optional, Any
from tooluniverse import ToolUniverse


class TargetValidationPipeline:
    """Target validation pipeline with 14 phases."""

    def __init__(self, tu: Optional[ToolUniverse] = None):
        self.tu = tu or ToolUniverse()
        self.tu.load_tools()
        self.ids = {}  # Resolved identifiers
        self.scores = {}  # Validation scores
        self.data = {}  # Collected data
        self.warnings = []  # Warnings and gaps
        self.tool_failures = []  # Track failed tools for Data Gaps

    def _handle_response(self, result: Any) -> Any:
        """Handle three different response formats from tools."""
        if result is None:
            return None
        if isinstance(result, list):
            return result
        if isinstance(result, dict):
            if 'status' in result:
                if result['status'] == 'error':
                    return None
                return result.get('data', result.get('content', result))
            if 'data' in result:
                return result['data']
            return result
        return result

    def _safe_call(self, tool_name: str, **kwargs) -> Any:
        """Safe tool call with error handling."""
        try:
            tool = getattr(self.tu.tools, tool_name)
            result = tool(**kwargs)
            return self._handle_response(result)
        except Exception as e:
            self.warnings.append(f"{tool_name} failed: {e}")
            self.tool_failures.append({
                'tool': tool_name,
                'params': kwargs,
                'error': str(e)
            })
            return None
```

---

## Phase 0: Target Disambiguation

```python
def resolve_target_ids(self, target: str) -> Dict[str, Any]:
    """
    Resolve target query to ALL needed identifiers.
    Returns dict with all cross-references.
    """
    ids = {
        'query': target,
        'uniprot': None,
        'ensembl': None,
        'ensembl_versioned': None,  # CRITICAL for GTEx
        'symbol': None,
        'entrez': None,
        'chembl_target': None,
        'hgnc': None,
        'full_name': None,
        'synonyms': [],
        'target_class': None,
        'is_gpcr': False
    }

    # Step 1: Initial query via MyGene (NOTE: uses `query` parameter)
    try:
        result = self._safe_call('MyGene_query_genes', query=target, limit=1)
        if result:
            gene = result[0] if isinstance(result, list) else result
            ids['symbol'] = gene.get('symbol')
            ids['ensembl'] = gene.get('ensembl', {}).get('gene') if isinstance(gene.get('ensembl'), dict) else gene.get('ensembl')
            ids['entrez'] = gene.get('entrezgene')
            ids['full_name'] = gene.get('name', '')
    except Exception as e:
        self.warnings.append(f"MyGene query failed: {e}")

    # Step 2: UniProt ID mapping
    # CRITICAL: Uses `from_db`, `to_db`, `ids` (NOT `_from`, `to`)
    if not ids['uniprot'] and ids['symbol']:
        try:
            mapping = self._safe_call(
                'UniProt_id_mapping',
                from_db='Gene_Name',
                to_db='UniProtKB',
                ids=ids['symbol']
            )
            if mapping and 'results' in mapping:
                ids['uniprot'] = mapping['results'][0]['to']['primaryAccession']
        except Exception:
            pass

    # Step 3: Get versioned Ensembl ID (CRITICAL for GTEx)
    # NOTE: ensembl_lookup_gene uses `gene_id` + `species="homo_sapiens"`
    if ids['ensembl']:
        try:
            gene_info = self._safe_call(
                'ensembl_lookup_gene',
                gene_id=ids['ensembl'],
                species="homo_sapiens"
            )
            if gene_info:
                if gene_info.get('version'):
                    ids['ensembl_versioned'] = f"{ids['ensembl']}.{gene_info['version']}"
                if not ids['full_name']:
                    ids['full_name'] = gene_info.get('description', '').split(' [')[0]
        except Exception as e:
            self.warnings.append(f"Ensembl lookup failed: {e}")

    # Step 4: Get ChEMBL target ID
    if ids['symbol']:
        try:
            chembl = self._safe_call('ChEMBL_search_targets', query=ids['symbol'])
            if chembl and 'targets' in chembl:
                for t in chembl['targets']:
                    if t.get('target_type') == 'SINGLE_PROTEIN':
                        ids['chembl_target'] = t['target_chembl_id']
                        break
        except Exception:
            pass

    # Step 5: GPCR detection (NOTE: requires `operation` parameter)
    if ids['symbol']:
        try:
            entry_name = f"{ids['symbol'].lower()}_human"
            gpcr = self._safe_call(
                'GPCRdb_get_protein',
                operation="get_protein",
                protein=entry_name
            )
            if gpcr:
                ids['is_gpcr'] = True
                ids['target_class'] = 'GPCR'
        except Exception:
            pass

    # Step 6: Get synonyms for collision detection
    if ids['uniprot']:
        try:
            alt_names = self._safe_call(
                'UniProt_get_alternative_names_by_accession',
                accession=ids['uniprot']
            )
            if alt_names:
                if isinstance(alt_names, list):
                    ids['synonyms'].extend(alt_names[:5])
                else:
                    ids['synonyms'].append(str(alt_names))
        except Exception:
            pass

    self.ids = ids
    return ids
```

---

## Phase 1: Open Targets Foundation

```python
def get_open_targets_foundation(self) -> Dict[str, Any]:
    """
    Open Targets foundation data - fills gaps for all subsequent phases.
    ALWAYS run this first after disambiguation.
    """
    ensembl_id = self.ids.get('ensembl')
    if not ensembl_id:
        return {'status': 'skipped', 'reason': 'No Ensembl ID'}

    results = {}

    # 1. Disease associations (for auto-discovery and scoring)
    results['diseases'] = self._safe_call(
        'OpenTargets_get_diseases_phenotypes_by_target_ensemblId',
        ensemblId=ensembl_id
    ) or {'note': 'No disease associations'}

    # 2. Tractability assessment
    results['tractability'] = self._safe_call(
        'OpenTargets_get_target_tractability_by_ensemblId',
        ensemblId=ensembl_id
    ) or {'note': 'No tractability data'}

    # 3. Safety profile
    results['safety'] = self._safe_call(
        'OpenTargets_get_target_safety_profile_by_ensemblId',
        ensemblId=ensembl_id
    ) or {'note': 'No safety liabilities'}

    # 4. Interactions
    results['interactions'] = self._safe_call(
        'OpenTargets_get_target_interactions_by_ensemblId',
        ensemblId=ensembl_id
    ) or {'note': 'No interactions'}

    # 5. GO terms
    results['go_terms'] = self._safe_call(
        'OpenTargets_get_target_gene_ontology_by_ensemblId',
        ensemblId=ensembl_id
    ) or {'note': 'No GO annotations'}

    # 6. Publications (CRITICAL: uses `entityId`, NOT `ensemblId`)
    results['publications'] = self._safe_call(
        'OpenTargets_get_publications_by_target_ensemblId',
        entityId=ensembl_id  # NOT ensemblId!
    ) or {'note': 'No publications'}

    # 7. Mouse models
    results['mouse_models'] = self._safe_call(
        'OpenTargets_get_biological_mouse_models_by_ensemblId',
        ensemblId=ensembl_id
    ) or {'note': 'No mouse model data'}

    # 8. Chemical probes
    results['chemical_probes'] = self._safe_call(
        'OpenTargets_get_chemical_probes_by_target_ensemblId',
        ensemblId=ensembl_id
    ) or {'note': 'No chemical probes'}

    # 9. Associated drugs (CRITICAL: requires `size` parameter)
    results['drugs'] = self._safe_call(
        'OpenTargets_get_associated_drugs_by_target_ensemblId',
        ensemblId=ensembl_id,
        size=100  # REQUIRED!
    ) or {'note': 'No drugs found'}

    # 10. Target classes
    results['classes'] = self._safe_call(
        'OpenTargets_get_target_classes_by_ensemblId',
        ensemblId=ensembl_id
    ) or {'note': 'No target classes'}

    # 11. Homologues (for paralog safety assessment)
    results['homologues'] = self._safe_call(
        'OpenTargets_get_target_homologues_by_ensemblId',
        ensemblId=ensembl_id
    ) or {'note': 'No homologues'}

    self.data['ot_foundation'] = results
    return results
```

---

## Auto Disease Discovery

```python
def auto_discover_diseases(self, top_n: int = 3) -> List[Dict[str, Any]]:
    """
    Auto-discover top associated diseases from Open Targets.
    Used when disease parameter not provided.
    """
    diseases_data = self.data.get('ot_foundation', {}).get('diseases', {})

    # Handle different response formats
    if isinstance(diseases_data, dict) and 'data' in diseases_data:
        diseases = diseases_data['data']
    elif isinstance(diseases_data, list):
        diseases = diseases_data
    else:
        return []

    # Sort by association score
    sorted_diseases = sorted(
        diseases,
        key=lambda x: x.get('associationScore', 0) if isinstance(x, dict) else 0,
        reverse=True
    )

    # Filter to therapeutic areas (exclude broad phenotypes)
    relevant_diseases = []
    for d in sorted_diseases[:top_n * 3]:
        if isinstance(d, dict):
            efo_id = d.get('id', '')
            # Skip broad terms
            if not any(x in efo_id.lower() for x in ['measurement', 'procedure', 'attribute']):
                relevant_diseases.append({
                    'name': d.get('name', 'Unknown'),
                    'efo_id': efo_id,
                    'score': d.get('associationScore', 0)
                })
        if len(relevant_diseases) >= top_n:
            break

    return relevant_diseases[:top_n]
```

---

## Phase 2: Core Identity (UniProt Details)

```python
def get_uniprot_details(self) -> Dict[str, Any]:
    """Get detailed protein information from UniProt."""
    uniprot_id = self.ids.get('uniprot')
    if not uniprot_id:
        return {'status': 'skipped', 'reason': 'No UniProt ID'}

    results = {}

    # Complete entry (includes PDB cross-references)
    results['entry'] = self._safe_call(
        'UniProt_get_entry_by_accession',
        accession=uniprot_id
    )

    # Function (NOTE: returns LIST of strings, not dict)
    functions = self._safe_call(
        'UniProt_get_function_by_accession',
        accession=uniprot_id
    )
    results['functions'] = functions if isinstance(functions, list) else [str(functions)] if functions else []

    # Subcellular location
    results['location'] = self._safe_call(
        'UniProt_get_subcellular_location_by_accession',
        accession=uniprot_id
    )

    # Recommended name
    results['recommended_name'] = self._safe_call(
        'UniProt_get_recommended_name_by_accession',
        accession=uniprot_id
    )

    self.data['uniprot'] = results
    return results
```

---

## Phase 3: Structure & Domains

```python
def get_structure_data(self) -> Dict[str, Any]:
    """Get structural biology data from PDB, AlphaFold, and InterPro."""
    uniprot_id = self.ids.get('uniprot')
    results = {'pdb_structures': [], 'alphafold': None, 'domains': []}

    if not uniprot_id:
        return results

    # Step 1: Extract PDB cross-references from UniProt entry
    entry = self.data.get('uniprot', {}).get('entry', {})
    if entry and 'uniProtKBCrossReferences' in entry:
        for xref in entry['uniProtKBCrossReferences']:
            if xref.get('database') == 'PDB':
                results['pdb_structures'].append({
                    'pdb_id': xref.get('id'),
                    'method': xref.get('properties', {}).get('Method', 'Unknown'),
                    'resolution': xref.get('properties', {}).get('Resolution', 'N/A')
                })

    # Step 2: AlphaFold prediction (NOTE: uses `qualifier` parameter)
    results['alphafold'] = self._safe_call(
        'alphafold_get_prediction',
        qualifier=uniprot_id
    )
    results['alphafold_summary'] = self._safe_call(
        'alphafold_get_summary',
        qualifier=uniprot_id
    )

    # Step 3: Domain architecture (CRITICAL: uses `protein_id`, not `uniprot_accession`)
    results['domains'] = self._safe_call(
        'InterPro_get_protein_domains',
        protein_id=uniprot_id
    ) or []

    # Step 4: GPCR special handling
    if self.ids.get('is_gpcr'):
        entry_name = f"{self.ids['symbol'].lower()}_human"
        results['gpcr_structures'] = self._safe_call(
            'GPCRdb_get_structures',
            operation="get_structures",
            protein=entry_name
        )

    self.data['structure'] = results
    return results
```

---

## Phase 4: Function & Pathways

```python
def get_pathway_data(self) -> Dict[str, Any]:
    """Get pathway and GO annotations."""
    uniprot_id = self.ids.get('uniprot')
    symbol = self.ids.get('symbol')
    results = {}

    # Reactome (CRITICAL: uses `uniprot_id` parameter, NOT `id`)
    results['reactome'] = self._safe_call(
        'Reactome_map_uniprot_to_pathways',
        uniprot_id=uniprot_id
    ) or []

    # KEGG
    results['kegg'] = self._safe_call(
        'kegg_get_gene_info',
        gene_id=symbol
    )

    # WikiPathways
    results['wikipathways'] = self._safe_call(
        'WikiPathways_search',
        query=symbol
    )

    # GO Annotations
    results['go'] = self._safe_call(
        'GO_get_annotations_for_gene',
        gene_id=symbol
    )

    self.data['pathways'] = results
    return results
```

---

## Phase 5: Protein Interactions

```python
def get_ppi_data(self) -> Dict[str, Any]:
    """Get protein-protein interaction data with fallback chains."""
    uniprot_id = self.ids.get('uniprot')
    symbol = self.ids.get('symbol')
    results = {'interactors': [], 'source': None}

    # Primary: STRING (CRITICAL: uses list format for protein_ids)
    string_result = self._safe_call(
        'STRING_get_protein_interactions',
        protein_ids=[uniprot_id],  # LIST format!
        species=9606
    )

    if string_result and len(string_result) >= 10:
        results['interactors'] = string_result
        results['source'] = 'STRING'
    else:
        # Fallback 1: IntAct (uses UniProt accession)
        intact_result = self._safe_call(
            'intact_get_interactions',
            identifier=uniprot_id
        )
        if intact_result and len(intact_result) >= 10:
            results['interactors'] = intact_result
            results['source'] = 'IntAct'
        else:
            # Fallback 2: BioGRID (uses gene symbol)
            biogrid_result = self._safe_call(
                'BioGRID_get_interactions',
                gene_symbol=symbol
            )
            if biogrid_result:
                results['interactors'] = biogrid_result
                results['source'] = 'BioGRID'
            else:
                # Fallback 3: Open Targets interactions (from Phase 1)
                ot_interactions = self.data.get('ot_foundation', {}).get('interactions', {})
                if ot_interactions:
                    results['interactors'] = ot_interactions
                    results['source'] = 'OpenTargets'

    # Verify minimum
    if len(results['interactors']) < 10:
        self.warnings.append(
            f"PPIs: Only {len(results['interactors'])} interactors found (minimum 10)"
        )

    self.data['ppi'] = results
    return results
```

---

## Phase 6: Expression Profile

```python
def get_expression_data(self) -> Dict[str, Any]:
    """Get tissue expression data with GTEx versioned ID fallback."""
    results = {'gtex': None, 'hpa': None, 'source': None}

    gencode_id = self.ids.get('ensembl_versioned') or self.ids.get('ensembl')
    symbol = self.ids.get('symbol')

    # Primary: GTEx (CRITICAL: requires `operation="get_median_gene_expression"`)
    if gencode_id:
        gtex_result = self._safe_call(
            'GTEx_get_median_gene_expression',
            gencode_id=gencode_id,
            operation="get_median_gene_expression"  # REQUIRED!
        )

        if gtex_result:
            results['gtex'] = gtex_result
            results['source'] = 'GTEx'
        else:
            # Fallback: Try unversioned ID if versioned failed
            if self.ids.get('ensembl_versioned'):
                gtex_result = self._safe_call(
                    'GTEx_get_median_gene_expression',
                    gencode_id=self.ids['ensembl'],
                    operation="get_median_gene_expression"
                )
                if gtex_result:
                    results['gtex'] = gtex_result
                    results['source'] = 'GTEx (unversioned)'

    # Fallback: HPA
    if not results['gtex']:
        # HPA comprehensive data (CRITICAL: requires all 3 boolean params)
        hpa_result = self._safe_call(
            'HPA_get_comprehensive_gene_details_by_ensembl_id',
            ensembl_id=self.ids.get('ensembl'),
            include_images=False,
            include_antibodies=False,
            include_expression=True
        )

        if hpa_result:
            results['hpa'] = hpa_result
            results['source'] = 'HPA'

        # HPA RNA expression (CRITICAL: requires ALL 3 parameters)
        hpa_rna = self._safe_call(
            'HPA_get_rna_expression_by_source',
            gene_name=symbol,
            source_type='tissue',
            source_name='all'
        )
        if hpa_rna:
            results['hpa_rna'] = hpa_rna

    # Verify minimum: top 10 tissues
    expression_count = 0
    if results['gtex'] and isinstance(results['gtex'], dict):
        expression_count = len(results['gtex'].get('data', []))
    elif results['hpa']:
        expression_count = len(results['hpa'].get('rna', {}).get('tissue', []))

    if expression_count < 10:
        self.warnings.append(f"Expression: Only {expression_count} tissues found (minimum 10)")

    self.data['expression'] = results
    return results
```

---

## Phase 7: Genetic Variation

```python
def get_genetic_data(self) -> Dict[str, Any]:
    """Get genetic variation and constraint data."""
    symbol = self.ids.get('symbol')
    results = {}

    # gnomAD constraints (CRITICAL: uses `gene_symbol`, not `gene_id`)
    constraints = self._safe_call(
        'gnomad_get_gene_constraints',
        gene_symbol=symbol
    )

    if constraints:
        results['constraints'] = {
            'pLI': constraints.get('pLI'),
            'LOEUF': constraints.get('LOEUF'),
            'missense_z': constraints.get('missense_z'),
            'pRec': constraints.get('pRec')
        }
        # Verify all 4 scores present
        missing = [k for k, v in results['constraints'].items() if v is None]
        if missing:
            self.warnings.append(f"gnomAD: Missing constraint scores: {missing}")
    else:
        self.warnings.append("gnomAD: No constraint data available")
        results['constraints'] = None

    # ClinVar
    results['clinvar'] = self._safe_call(
        'clinvar_search_variants',
        gene=symbol
    )

    # CIViC (cancer variants)
    results['civic'] = self._safe_call(
        'civic_get_variants_by_gene',
        gene_symbol=symbol
    )

    # cBioPortal (cancer mutations)
    results['cbioportal'] = self._safe_call(
        'cBioPortal_get_mutations',
        gene_symbol=symbol
    )

    self.data['genetics'] = results
    return results
```

---

## Phase 8: Disease Association Scoring

```python
def score_disease_association(self, disease: Optional[str] = None) -> Dict[str, Any]:
    """
    Calculate disease association score (0-30 pts).
    """
    scores = {'genetic': 0, 'literature': 0, 'pathway': 0, 'total': 0}
    evidence = []

    # Get disease for scoring
    if not disease:
        top_diseases = self.auto_discover_diseases(top_n=1)
        if top_diseases:
            disease = top_diseases[0]['name']

    symbol = self.ids.get('symbol')
    ensembl_id = self.ids.get('ensembl')

    # 1. Genetic Evidence (0-10)
    # GWAS associations (CRITICAL: uses `mapped_gene`, not `gene`)
    if symbol:
        gwas = self._safe_call('gwas_get_snps_for_gene', mapped_gene=symbol)
        if gwas:
            associations = gwas.get('associations', []) if isinstance(gwas, dict) else gwas
            significant = [a for a in associations if isinstance(a, dict) and a.get('pvalue', 1) < 5e-8]
            scores['genetic'] += min(len(significant) * 3, 6)
            if significant:
                evidence.append(f"GWAS: {len(significant)} significant loci [T3]")

    # Constraint scores
    constraints = self.data.get('genetics', {}).get('constraints', {})
    if constraints:
        pli = constraints.get('pLI', 0)
        if pli and pli > 0.9:
            scores['genetic'] += 2
            evidence.append(f"pLI={pli:.2f} (highly constrained) [T3]")

    # 2. Literature Evidence (0-10)
    if symbol and disease:
        pubs = self._safe_call(
            'PubMed_search_articles',
            query=f"{symbol} AND {disease}",
            limit=200
        )
        count = len(pubs) if isinstance(pubs, list) else (pubs.get('total', 0) if isinstance(pubs, dict) else 0)

        if count > 100: scores['literature'] = 10
        elif count > 50: scores['literature'] = 7
        elif count > 10: scores['literature'] = 5
        elif count > 0: scores['literature'] = 3

        evidence.append(f"Literature: {count} publications [T4]")

    # 3. Pathway Evidence (0-10)
    diseases_data = self.data.get('ot_foundation', {}).get('diseases', {})
    if isinstance(diseases_data, dict) and 'data' in diseases_data:
        for d in diseases_data['data']:
            if disease and disease.lower() in d.get('name', '').lower():
                score = d.get('associationScore', 0)
                if score > 0.8: scores['pathway'] = 10
                elif score > 0.5: scores['pathway'] = 7
                elif score > 0.2: scores['pathway'] = 4
                else: scores['pathway'] = 1
                evidence.append(f"OpenTargets score={score:.2f} [T3]")
                break

    scores['total'] = scores['genetic'] + scores['literature'] + scores['pathway']
    self.scores['disease_association'] = scores

    return {'disease': disease, 'scores': scores, 'evidence': evidence}
```

---

## Phase 9: Druggability Assessment

```python
def score_druggability(self, modality: str = 'all') -> Dict[str, Any]:
    """Calculate druggability score (0-25 pts)."""
    scores = {'structural': 0, 'chemical': 0, 'target_class': 0, 'total': 0}
    evidence = []

    ensembl_id = self.ids.get('ensembl')
    uniprot_id = self.ids.get('uniprot')
    symbol = self.ids.get('symbol')

    # 1. Structural Tractability (0-10)
    tractability = self.data.get('ot_foundation', {}).get('tractability', {})

    if modality in ['small_molecule', 'all']:
        sm_bucket = tractability.get('smallMolecule', {}).get('bucket', 0)
        if sm_bucket and sm_bucket <= 3:
            scores['structural'] = 10
        elif sm_bucket and sm_bucket <= 5:
            scores['structural'] = 7
        elif sm_bucket and sm_bucket <= 7:
            scores['structural'] = 5
        elif sm_bucket:
            scores['structural'] = 2
        if sm_bucket:
            evidence.append(f"SM tractability bucket: {sm_bucket} [T3]")

    # 2. Chemical Matter (0-10)
    chembl_id = self.ids.get('chembl_target')

    if chembl_id:
        # CRITICAL: uses `target_chembl_id__exact` with double underscore
        activities = self._safe_call(
            'ChEMBL_get_target_activities',
            target_chembl_id__exact=chembl_id
        )

        if activities:
            # Handle response format
            if isinstance(activities, dict):
                compounds = activities.get('compounds', activities.get('data', []))
            else:
                compounds = activities if isinstance(activities, list) else []

            potent = [c for c in compounds if isinstance(c, dict) and c.get('standard_value', 10000) < 100]

            if potent:
                scores['chemical'] = 10
                evidence.append(f"{len(potent)} compounds with IC50 < 100nM [T2]")
            elif compounds:
                scores['chemical'] = 7
                evidence.append(f"{len(compounds)} compounds in ChEMBL [T3]")

    # Fallback: BindingDB
    if scores['chemical'] < 10 and uniprot_id:
        ligands = self._safe_call(
            'BindingDB_get_ligands_by_uniprot',
            uniprot=uniprot_id,
            affinity_cutoff=1000
        )
        if ligands and len(ligands) > 0:
            scores['chemical'] = max(scores['chemical'], 7)
            evidence.append(f"BindingDB: {len(ligands)} ligands [T2]")

    # 3. Target Class Bonus (0-5)
    if symbol:
        pharos = self._safe_call('Pharos_get_target', gene=symbol)
        if pharos and 'tdl' in pharos:
            tdl = pharos['tdl']
            if tdl == 'Tclin':
                scores['target_class'] = 5
                evidence.append("Pharos TDL: Tclin (clinical target) [T1]")
            elif tdl == 'Tchem':
                scores['target_class'] = 4
                evidence.append("Pharos TDL: Tchem (chemical probe) [T2]")
            elif tdl == 'Tbio':
                scores['target_class'] = 2
                evidence.append("Pharos TDL: Tbio (biology known) [T3]")

    # GPCR bonus
    if self.ids.get('is_gpcr'):
        scores['target_class'] = max(scores['target_class'], 5)
        evidence.append("GPCR target class - validated druggable [T1]")

    scores['total'] = scores['structural'] + scores['chemical'] + scores['target_class']
    self.scores['druggability'] = scores

    return {'modality': modality, 'scores': scores, 'evidence': evidence}
```

---

## Phase 10: Safety Analysis

```python
def score_safety(self) -> Dict[str, Any]:
    """Calculate safety score (0-20 pts)."""
    scores = {'expression': 0, 'genetic': 0, 'adverse': 0, 'total': 0}
    evidence = []
    safety_flags = []

    critical_tissues = ['heart', 'liver', 'kidney', 'brain', 'bone marrow']

    # 1. Expression Selectivity (0-5)
    expression_data = self.data.get('expression', {})
    gtex = expression_data.get('gtex', {})

    expression_in_critical = []
    if isinstance(gtex, dict) and 'data' in gtex:
        for tissue_data in gtex['data']:
            tissue = tissue_data.get('tissue', '').lower()
            tpm = tissue_data.get('median', 0)
            if any(c in tissue for c in critical_tissues) and tpm > 10:
                expression_in_critical.append({'tissue': tissue, 'tpm': tpm})

    if not expression_in_critical:
        scores['expression'] = 5
        evidence.append("Low expression in critical tissues [T2]")
    elif len(expression_in_critical) == 1:
        scores['expression'] = 4
        evidence.append(f"Moderate expression in {expression_in_critical[0]['tissue']} [T2]")
    else:
        scores['expression'] = 0
        safety_flags.append(f"High expression in: {', '.join([e['tissue'] for e in expression_in_critical])}")
        evidence.append(f"Expression in critical tissues: {[e['tissue'] for e in expression_in_critical]} [T2]")

    # 2. Genetic Validation (0-10)
    mouse_models = self.data.get('ot_foundation', {}).get('mouse_models', {})

    if isinstance(mouse_models, dict) and 'data' in mouse_models:
        models = mouse_models['data']
        lethal = any('lethal' in str(m.get('phenotype_label', '')).lower() for m in models if isinstance(m, dict))

        if lethal:
            scores['genetic'] = 0
            safety_flags.append("Mouse KO lethal")
            evidence.append("Mouse KO: Lethal phenotype [T2]")
        elif models:
            scores['genetic'] = 7
            evidence.append("Mouse KO: Viable with phenotype [T2]")
        else:
            # Fall back to pLI
            constraints = self.data.get('genetics', {}).get('constraints', {})
            if constraints:
                pli = constraints.get('pLI', 0.5)
                if pli < 0.5:
                    scores['genetic'] = 5
                    evidence.append(f"No KO data, low pLI ({pli:.2f}) [T3]")
                else:
                    scores['genetic'] = 2
                    evidence.append(f"No KO data, high pLI ({pli:.2f}) - caution [T3]")

    # 3. Known ADRs (0-5)
    safety_profile = self.data.get('ot_foundation', {}).get('safety', {})

    if isinstance(safety_profile, dict) and 'data' in safety_profile:
        liabilities = safety_profile.get('data', [])
        severe = [l for l in liabilities if isinstance(l, dict) and l.get('severity') == 'High']

        if not liabilities:
            scores['adverse'] = 5
            evidence.append("No known safety liabilities [T2]")
        elif severe:
            scores['adverse'] = 1
            safety_flags.append(f"Severe safety concerns: {len(severe)}")
            evidence.append(f"Severe safety liabilities: {len(severe)} [T2]")
        else:
            scores['adverse'] = 3
            evidence.append(f"Mild/moderate safety concerns: {len(liabilities)} [T2]")

    scores['total'] = scores['expression'] + scores['genetic'] + scores['adverse']
    self.scores['safety'] = scores
    self.safety_flags = safety_flags

    return {'scores': scores, 'evidence': evidence, 'safety_flags': safety_flags}
```

---

## Phase 11: Clinical Precedent

```python
def score_clinical_precedent(self) -> Dict[str, Any]:
    """Calculate clinical precedent score (0-15 pts)."""
    score = 0
    evidence = []
    approved_drugs = []
    clinical_trials = []

    drugs_data = self.data.get('ot_foundation', {}).get('drugs', {})

    if isinstance(drugs_data, dict) and 'data' in drugs_data:
        for drug in drugs_data['data']:
            if not isinstance(drug, dict):
                continue
            phase = drug.get('phase', 0)
            drug_name = drug.get('name', 'Unknown')

            if phase == 4:  # Approved
                approved_drugs.append({
                    'name': drug_name,
                    'phase': phase,
                    'indication': drug.get('indication', 'Unknown')
                })
            elif phase in [1, 2, 3]:
                clinical_trials.append({
                    'name': drug_name,
                    'phase': phase
                })

    # Score based on highest stage
    if approved_drugs:
        score = 15
        evidence.append(f"{len(approved_drugs)} FDA-approved drugs [T1]")
    elif any(t['phase'] == 3 for t in clinical_trials):
        score = 10
        evidence.append("Phase 3 clinical trials [T2]")
    elif any(t['phase'] == 2 for t in clinical_trials):
        score = 7
        evidence.append("Phase 2 clinical trials [T2]")
    elif any(t['phase'] == 1 for t in clinical_trials):
        score = 5
        evidence.append("Phase 1 clinical trials [T2]")
    elif clinical_trials:
        score = 3
        evidence.append("Preclinical compounds [T3]")
    else:
        score = 0
        evidence.append("No clinical development [T4]")

    self.scores['clinical_precedent'] = {'score': score, 'max': 15}
    self.data['approved_drugs'] = approved_drugs
    self.data['clinical_trials'] = clinical_trials

    return {
        'score': score,
        'evidence': evidence,
        'approved_drugs': approved_drugs[:5],
        'clinical_trials': clinical_trials[:10]
    }
```

---

## Phase 12: Validation Evidence

```python
def score_validation_evidence(self) -> Dict[str, Any]:
    """Calculate validation evidence score (0-10 pts)."""
    scores = {'functional': 0, 'models': 0, 'total': 0}
    evidence = []

    # Check mouse models for functional validation
    mouse_models = self.data.get('ot_foundation', {}).get('mouse_models', {})
    if isinstance(mouse_models, dict) and 'data' in mouse_models:
        models = mouse_models['data']
        if models:
            # Check for relevant phenotypes
            has_phenotype = any(
                m.get('phenotype_label') for m in models if isinstance(m, dict)
            )
            if has_phenotype:
                scores['functional'] = 3
                evidence.append("Mouse model with relevant phenotype [T2]")

    # Default validation score
    scores['total'] = scores['functional'] + scores['models']
    self.scores['validation_evidence'] = scores

    return {'scores': scores, 'evidence': evidence}
```

---

## Phase 13: Composite Scoring

```python
def calculate_composite_score(self) -> Dict[str, Any]:
    """Calculate total validation score (0-100) and assign tier."""
    disease_score = self.scores.get('disease_association', {}).get('total', 0)
    druggability_score = self.scores.get('druggability', {}).get('total', 0)
    safety_score = self.scores.get('safety', {}).get('total', 0)
    clinical_score = self.scores.get('clinical_precedent', {}).get('score', 0)
    validation_score = self.scores.get('validation_evidence', {}).get('total', 5)

    total = (disease_score + druggability_score + safety_score +
             clinical_score + validation_score)

    # Assign tier
    if total >= 80:
        tier, recommendation = 1, "GO - Highly validated target"
    elif total >= 60:
        tier, recommendation = 2, "CONDITIONAL GO - Needs focused validation"
    elif total >= 40:
        tier, recommendation = 3, "CAUTION - Significant validation needed"
    else:
        tier, recommendation = 4, "NO-GO - Consider alternatives"

    return {
        'total': total,
        'tier': tier,
        'recommendation': recommendation,
        'components': {
            'disease_association': {'score': disease_score, 'max': 30},
            'druggability': {'score': druggability_score, 'max': 25},
            'safety': {'score': safety_score, 'max': 20},
            'clinical_precedent': {'score': clinical_score, 'max': 15},
            'validation_evidence': {'score': validation_score, 'max': 10}
        }
    }
```

---

## Completeness Verification

```python
def verify_completeness(self) -> Dict[str, Any]:
    """Verify minimum data requirements are met."""
    issues = []

    # Check identifiers
    if not self.ids.get('uniprot'):
        issues.append("Missing UniProt ID")
    if not self.ids.get('ensembl'):
        issues.append("Missing Ensembl ID")

    # Check Open Targets foundation
    ot = self.data.get('ot_foundation', {})
    required_ot = ['diseases', 'tractability', 'safety', 'drugs']
    for key in required_ot:
        if not ot.get(key) or ot[key].get('note'):
            issues.append(f"Open Targets {key} not available")

    # Check expression
    expr = self.data.get('expression', {})
    if not expr.get('gtex') and not expr.get('hpa'):
        issues.append("No expression data from GTEx or HPA")

    # Check constraints
    genetics = self.data.get('genetics', {})
    constraints = genetics.get('constraints', {})
    if not constraints:
        issues.append("No gnomAD constraint data")
    else:
        missing = [k for k, v in constraints.items() if v is None]
        if missing:
            issues.append(f"Missing constraint scores: {missing}")

    # Check PPIs
    ppi = self.data.get('ppi', {})
    if len(ppi.get('interactors', [])) < 10:
        issues.append(f"Only {len(ppi.get('interactors', []))} PPIs (minimum 10)")

    return {
        'complete': len(issues) == 0,
        'issues': issues,
        'tool_failures': self.tool_failures,
        'warnings': self.warnings
    }
```

---

## Main Pipeline Function

```python
def run_validation_pipeline(
    target: str,
    disease: Optional[str] = None,
    modality: str = 'all',
    output_format: str = 'markdown'
) -> Dict[str, Any]:
    """
    Run the complete target validation pipeline.
    """
    pipeline = TargetValidationPipeline()

    # Phase 0: Disambiguation
    print(f"Phase 0: Resolving target '{target}'...")
    ids = pipeline.resolve_target_ids(target)

    if not ids.get('symbol') and not ids.get('uniprot'):
        return {'error': f"Could not resolve target: {target}"}

    print(f"  Resolved: {ids.get('symbol')} ({ids.get('uniprot')})")

    # Phase 1: Open Targets Foundation
    print("Phase 1: Fetching Open Targets foundation data...")
    ot_data = pipeline.get_open_targets_foundation()

    # Phase 2: UniProt Details
    print("Phase 2: Fetching UniProt details...")
    pipeline.get_uniprot_details()

    # Phase 3: Structure
    print("Phase 3: Fetching structure data...")
    pipeline.get_structure_data()

    # Phase 4: Pathways
    print("Phase 4: Fetching pathway data...")
    pipeline.get_pathway_data()

    # Phase 5: PPIs
    print("Phase 5: Fetching PPI data...")
    pipeline.get_ppi_data()

    # Phase 6: Expression
    print("Phase 6: Fetching expression data...")
    pipeline.get_expression_data()

    # Phase 7: Genetics
    print("Phase 7: Fetching genetic data...")
    pipeline.get_genetic_data()

    # Auto-discover diseases if not provided
    if not disease:
        top_diseases = pipeline.auto_discover_diseases(top_n=3)
        if top_diseases:
            disease = top_diseases[0]['name']
            print(f"  Auto-discovered disease: {disease}")

    # Phase 8: Disease Association Scoring
    print("Phase 8: Scoring disease association...")
    disease_result = pipeline.score_disease_association(disease)

    # Phase 9: Druggability Assessment
    print("Phase 9: Assessing druggability...")
    druggability_result = pipeline.score_druggability(modality)

    # Phase 10: Safety Analysis
    print("Phase 10: Analyzing safety profile...")
    safety_result = pipeline.score_safety()

    # Phase 11: Clinical Precedent
    print("Phase 11: Assessing clinical precedent...")
    clinical_result = pipeline.score_clinical_precedent()

    # Phase 12: Validation Evidence
    print("Phase 12: Assessing validation evidence...")
    validation_result = pipeline.score_validation_evidence()

    # Phase 13: Composite Scoring
    print("Phase 13: Calculating composite score...")
    composite = pipeline.calculate_composite_score()

    # Verify completeness
    completeness = pipeline.verify_completeness()

    # Compile results
    results = {
        'metadata': {
            'target': ids.get('symbol'),
            'uniprot_id': ids.get('uniprot'),
            'ensembl_id': ids.get('ensembl'),
            'disease': disease,
            'modality': modality,
            'report_date': datetime.now().strftime('%Y-%m-%d')
        },
        'identifiers': ids,
        'validation_score': composite,
        'disease_association': disease_result,
        'druggability': druggability_result,
        'safety': safety_result,
        'clinical_precedent': clinical_result,
        'validation_evidence': validation_result,
        'safety_flags': pipeline.safety_flags,
        'completeness': completeness,
        'data': pipeline.data
    }

    return results


if __name__ == "__main__":
    # Example usage
    result = run_validation_pipeline(
        target="EGFR",
        modality="small molecule",
        output_format="markdown"
    )
    print(f"\nValidation Score: {result['validation_score']['total']}/100")
    print(f"Tier: {result['validation_score']['tier']}")
    print(f"Recommendation: {result['validation_score']['recommendation']}")
```