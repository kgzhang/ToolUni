---
name: target-validation
description: Comprehensive target validation assistant - from biological intelligence to validation decisions in one assessment. Integrates protein information, disease associations, druggability, safety, and clinical data to generate quantitative scoring (0-100) with GO/NO-GO recommendations. Auto-discovers disease associations, supports multi-modality assessment (10+ modalities), outputs integrated report with visualizations and structured data. Use for target validation, prioritization, competitive analysis.
---

# Target Validation Pipeline

Validate drug target hypotheses using multi-dimensional computational evidence before committing to wet-lab work. Produces a quantitative Target Validation Score (0-100) with priority tier classification and GO/NO-GO recommendation.

## CRITICAL: Data Completeness Requirements

**Before scoring, VERIFY these minimums are met:**
- ✅ All identifiers resolved (UniProt, Ensembl, ChEMBL)
- ✅ Open Targets foundation data queried (diseases, tractability, safety, drugs)
- ✅ At least 5 disease associations with scores
- ✅ All 4 gnomAD constraint scores OR documented as unavailable
- ✅ Expression data from GTEx OR HPA
- ✅ At least 10 PPIs OR explanation for fewer
- ✅ At least 10 pathways OR explanation for fewer

**If minimums NOT met:**
1. Try fallback tools (see Fallback Chains section)
2. Document gaps in Data Gaps table
3. Continue with available data, noting limitations

---

## Workflow Overview

```
Phase -1: Tool Verification (CRITICAL - verify parameters first)
Phase  0: Target Disambiguation (resolve ALL identifiers)
Phase  1: Open Targets Foundation (PRIMARY data source - query FIRST)
Phase  2: Core Identity (UniProt, MyGene details)
Phase  3: Structure & Domains (PDB, AlphaFold, InterPro)
Phase  4: Function & Pathways (GO, Reactome, KEGG)
Phase  5: Protein Interactions (STRING, IntAct, BioGRID)
Phase  6: Expression Profile (GTEx, HPA, Cell Atlas)
Phase  7: Genetic Variation (gnomAD, ClinVar, cBioPortal)
Phase  8: Disease Scoring (0-30 pts)
Phase  9: Druggability Assessment (0-25 pts)
Phase 10: Safety Analysis (0-20 pts)
Phase 11: Clinical Precedent (0-15 pts)
Phase 12: Validation Evidence (0-10 pts)
Phase 13: Composite Scoring & Synthesis
Phase 14: Generate Report
```

---

## Phase -1: Tool Verification (ALWAYS FIRST)

**Verify tool parameters before calling unfamiliar tools.** Many API docs are wrong.

### Critical Parameter Corrections (MEMORIZE THESE)

| Tool | WRONG Parameter | CORRECT Parameter | Notes |
|------|-----------------|-------------------|-------|
| `UniProt_id_mapping` | `_from`, `to` | `from_db`, `to_db`, `ids` | All three required |
| `Reactome_map_uniprot_to_pathways` | `id` | `uniprot_id` | Use `uniprot_id` |
| `ensembl_get_xrefs` | `gene_id` | `id` | Just `id` |
| `GTEx_get_median_gene_expression` | `operation="median"` | `operation="get_median_gene_expression"` | Full operation name |
| `OpenTargets_get_publications_by_target_ensemblId` | `ensemblId` | `entityId` | NOT ensemblId |
| `OpenTargets_get_associated_drugs_by_target_ensemblId` | `ensemblId` only | `ensemblId` + `size` | size REQUIRED |
| `OpenTargets_target_disease_evidence` | just `ensemblId` | `ensemblId` + `efoId` | BOTH required |
| `STRING_get_protein_interactions` | single ID string | `protein_ids` (list), `species` | List format |
| `intact_get_interactions` | gene symbol | `identifier` (UniProt accession) | UniProt ID |
| `HPA_get_comprehensive_gene_details_by_ensembl_id` | `ensembl_id` only | `ensembl_id` + `include_images` + `include_antibodies` + `include_expression` | ALL 4 required |
| `HPA_get_rna_expression_by_source` | `ensembl_id` | `gene_name` + `source_type` + `source_name` | ALL 3 required |
| `alphafold_get_prediction` | `uniprot_accession` | `qualifier` | Use qualifier |
| `ChEMBL_get_target_activities` | `target_chembl_id` | `target_chembl_id__exact` | Double underscore |
| `MyGene_query_genes` | `q` | `query` | Use `query` |
| `search_clinical_trials` | `query` | `query_term` | Use `query_term` |
| `gnomad_get_gene_constraints` | `gene_id` | `gene_symbol` | Gene symbol |
| `InterPro_get_protein_domains` | `uniprot_accession` | `protein_id` | Use `protein_id` |
| `gwas_get_snps_for_gene` | `gene` | `mapped_gene` | Use `mapped_gene` |
| `ensembl_lookup_gene` | `id` | `gene_id` + `species="homo_sapiens"` | Both required |
| SOAP tools (GPCRdb, DisGeNET) | missing | `operation` | Required first param |

### Response Format Handling

Tools return THREE different formats - handle ALL:

```python
# Format 1: Standard wrapper
result = tool()
if isinstance(result, dict):
    if 'status' in result:
        data = result.get('data', result.get('content', []))
    elif 'data' in result:
        data = result['data']
    else:
        data = result  # Direct dict

# Format 2: Direct list
elif isinstance(result, list):
    data = result

# Format 3: Direct dict without wrapper
else:
    data = result
```

---

## Phase 0: Target Disambiguation

**Goal**: Resolve target to ALL identifiers before any analysis.

### Step-by-Step ID Resolution

```python
ids = {
    'query': target,
    'symbol': None,
    'uniprot': None,
    'ensembl': None,
    'ensembl_versioned': None,  # CRITICAL for GTEx
    'entrez': None,
    'chembl_target': None,
    'hgnc': None,
    'synonyms': []
}
```

### Tool Execution Order

| Step | Tool | Parameters | Output |
|------|------|------------|--------|
| 1 | `MyGene_query_genes` | `query=<target>` | symbol, ensembl, entrez |
| 2 | `UniProt_id_mapping` | `from_db='Gene_Name'`, `to_db='UniProtKB'`, `ids=<symbol>` | uniprot |
| 3 | `ensembl_lookup_gene` | `gene_id=<ensembl>`, `species="homo_sapiens"` | ensembl_versioned, description |
| 4 | `ChEMBL_search_targets` | `query=<symbol>` | chembl_target |
| 5 | `UniProt_get_alternative_names_by_accession` | `accession=<uniprot>` | synonyms (for collision detection) |

### Versioned ID Fallback (CRITICAL for GTEx)

```python
# GTEx OFTEN requires versioned IDs
if ids['ensembl']:
    gene_info = ensembl_lookup_gene(gene_id=ids['ensembl'], species="homo_sapiens")
    if gene_info and gene_info.get('version'):
        ids['ensembl_versioned'] = f"{ids['ensembl']}.{gene_info['version']}"
```

### GPCR Detection

```python
# Check if GPCR for specialized handling
entry_name = f"{symbol.lower()}_human"
gpcr = GPCRdb_get_protein(operation="get_protein", protein=entry_name)
if gpcr and gpcr.get('status') == 'success':
    ids['is_gpcr'] = True
```

---

## Phase 1: Open Targets Foundation (PRIMARY DATA SOURCE)

**Query Open Targets FIRST** - it provides baseline data for all subsequent phases.

### Foundation Queries (Execute ALL)

```python
ensembl_id = ids['ensembl']  # Use unversioned for Open Targets

# 1. Disease associations (for auto-discovery and scoring)
diseases = OpenTargets_get_diseases_phenotypes_by_target_ensemblId(ensemblId=ensembl_id)

# 2. Tractability assessment
tractability = OpenTargets_get_target_tractability_by_ensemblId(ensemblId=ensembl_id)

# 3. Safety profile
safety = OpenTargets_get_target_safety_profile_by_ensemblId(ensemblId=ensembl_id)

# 4. Protein interactions
interactions = OpenTargets_get_target_interactions_by_ensemblId(ensemblId=ensembl_id)

# 5. Gene Ontology
go_terms = OpenTargets_get_target_gene_ontology_by_ensemblId(ensemblId=ensembl_id)

# 6. Publications (NOTE: uses entityId, NOT ensemblId)
publications = OpenTargets_get_publications_by_target_ensemblId(entityId=ensembl_id)

# 7. Mouse models (KO phenotypes)
mouse_models = OpenTargets_get_biological_mouse_models_by_ensemblId(ensemblId=ensembl_id)

# 8. Chemical probes
probes = OpenTargets_get_chemical_probes_by_target_ensemblId(ensemblId=ensembl_id)

# 9. Associated drugs (NOTE: requires size parameter)
drugs = OpenTargets_get_associated_drugs_by_target_ensemblId(ensemblId=ensembl_id, size=100)

# 10. Target classes
classes = OpenTargets_get_target_classes_by_ensemblId(ensemblId=ensembl_id)

# 11. Homologues (for paralog safety)
homologues = OpenTargets_get_target_homologues_by_ensemblId(ensemblId=ensembl_id)
```

### ⚠️ Tool Availability Note

Some Open Targets tools may not be available in all installations. If `OpenTargets_*` tools fail, use these alternatives:

| Unavailable Tool | Alternative |
|------------------|-------------|
| `OpenTargets_get_diseases_phenotypes_by_target_ensemblId` | `search_clinical_trials` + `Pharos_get_target` |
| `OpenTargets_get_target_tractability_by_ensemblId` | `Pharos_get_target` (TDL field) |
| `OpenTargets_get_target_safety_profile_by_ensemblId` | `gnomad_get_gene_constraints` + literature |
| `OpenTargets_get_target_interactions_by_ensemblId` | `STRING_get_protein_interactions` |
| `OpenTargets_get_associated_drugs_by_target_ensemblId` | `search_clinical_trials` |
| `BioGRID_get_interactions` | `STRING` + `IntAct` combined |
| `DrugBank_search_drugs` | `search_clinical_trials` + `BindingDB` |

### Auto Disease Discovery

If no disease provided, extract top 3 from Open Targets:

```python
def auto_discover_diseases(diseases_data, top_n=3):
    if isinstance(diseases_data, dict) and 'data' in diseases_data:
        diseases = diseases_data['data']
    elif isinstance(diseases_data, list):
        diseases = diseases_data
    else:
        return []

    # Sort by association score, filter out broad phenotypes
    sorted_diseases = sorted(
        diseases,
        key=lambda x: x.get('associationScore', 0),
        reverse=True
    )

    relevant = []
    for d in sorted_diseases:
        efo_id = d.get('id', '')
        # Skip broad measurement/attribute terms
        if not any(x in efo_id.lower() for x in ['measurement', 'procedure', 'attribute']):
            relevant.append({
                'name': d.get('name'),
                'efo_id': efo_id,
                'score': d.get('associationScore', 0)
            })
        if len(relevant) >= top_n:
            break

    return relevant
```

---

## Phase 2: Core Identity

### UniProt Queries

```python
uniprot_id = ids['uniprot']

# Complete entry (includes PDB cross-references)
entry = UniProt_get_entry_by_accession(accession=uniprot_id)

# Function (NOTE: returns LIST of strings, not dict)
functions = UniProt_get_function_by_accession(accession=uniprot_id)
# functions is a list: ["Function 1...", "Function 2..."]

# Subcellular location
location = UniProt_get_subcellular_location_by_accession(accession=uniprot_id)

# Alternative names (for collision detection)
alt_names = UniProt_get_alternative_names_by_accession(accession=uniprot_id)
```

---

## Phase 3: Structure & Domains

### 3-Step Structure Search Chain

```python
structures = []
uniprot_id = ids['uniprot']

# Step 1: UniProt PDB cross-references (most reliable)
entry = UniProt_get_entry_by_accession(accession=uniprot_id)
if entry and 'uniProtKBCrossReferences' in entry:
    for xref in entry['uniProtKBCrossReferences']:
        if xref.get('database') == 'PDB':
            structures.append({
                'pdb_id': xref.get('id'),
                'method': xref.get('properties', {}).get('Method'),
                'resolution': xref.get('properties', {}).get('Resolution')
            })

# Step 2: AlphaFold (always available)
alphafold = alphafold_get_prediction(qualifier=uniprot_id)
alphafold_summary = alphafold_get_summary(qualifier=uniprot_id)

# Step 3: Domains (CRITICAL: uses `protein_id`, not `uniprot_accession`)
domains = InterPro_get_protein_domains(protein_id=uniprot_id)
```

### GPCR Special Handling

```python
if ids.get('is_gpcr'):
    entry_name = f"{ids['symbol'].lower()}_human"
    gpcr_structures = GPCRdb_get_structures(
        operation="get_structures",
        protein=entry_name
    )
```

---

## Phase 4: Function & Pathways

### Pathway Queries

```python
uniprot_id = ids['uniprot']
symbol = ids['symbol']
ensembl_id = ids['ensembl']

# Reactome (CRITICAL: uses `uniprot_id` parameter, NOT `id`)
reactome = Reactome_map_uniprot_to_pathways(uniprot_id=uniprot_id)

# KEGG
kegg = kegg_get_gene_info(gene_id=symbol)

# WikiPathways
wikipathways = WikiPathways_search(query=symbol)

# GO Annotations
go = GO_get_annotations_for_gene(gene_id=symbol)

# Enrichment analysis (if you have a gene list)
# enrichr = enrichr_gene_enrichment_analysis(gene_list=gene_list)
```

**Minimum**: 10 pathways OR documented explanation.

---

## Phase 5: Protein Interactions

### PPI Queries with Fallbacks

```python
uniprot_id = ids['uniprot']
ensembl_id = ids['ensembl']

# Primary: STRING (use list format for protein_ids)
string = STRING_get_protein_interactions(
    protein_ids=[uniprot_id],  # LIST format
    species=9606
)

# Fallback 1: IntAct (uses UniProt accession)
intact = intact_get_interactions(identifier=uniprot_id)

# Fallback 2: BioGRID (uses gene symbol)
biogrid = BioGRID_get_interactions(gene_symbol=ids['symbol'])

# Fallback 3: Open Targets interactions (already queried in Phase 1)
ot_interactions = ot_foundation.get('interactions', {})
```

**Minimum**: 20 interactors OR documented explanation.

---

## Phase 6: Expression Profile

### GTEx with Versioned ID Fallback

```python
# Try versioned ID first (GTEx often requires it)
gencode_id = ids.get('ensembl_versioned') or ids.get('ensembl')

gtex = GTEx_get_median_gene_expression(
    gencode_id=gencode_id,
    operation="get_median_gene_expression"  # REQUIRED parameter
)

# Handle response
if isinstance(gtex, dict):
    if 'data' in gtex:
        expression_data = gtex['data']
    elif gtex.get('status') == 'error':
        # Try unversioned ID
        gtex = GTEx_get_median_gene_expression(
            gencode_id=ids['ensembl'],
            operation="get_median_gene_expression"
        )

# Fallback: HPA (CRITICAL: requires all boolean parameters)
if not gtex or gtex.get('status') == 'error':
    hpa = HPA_get_comprehensive_gene_details_by_ensembl_id(
        ensembl_id=ids['ensembl'],
        include_images=False,
        include_antibodies=False,
        include_expression=True
    )
    # Also try RNA expression
    hpa_rna = HPA_get_rna_expression_by_source(
        gene_name=ids['symbol'],
        source_type='tissue',
        source_name='all'  # or specific tissue
    )
```

### Critical Tissue Expression Check

```python
critical_tissues = ['heart', 'liver', 'kidney', 'brain', 'bone marrow']
expression_in_critical = []

for tissue_data in expression_data:
    tissue = tissue_data.get('tissue', '').lower()
    tpm = tissue_data.get('median', 0)
    if any(c in tissue for c in critical_tissues) and tpm > 10:
        expression_in_critical.append({'tissue': tissue, 'tpm': tpm})
```

**Minimum**: Top 10 tissues with TPM values.

---

## Phase 7: Genetic Variation

### Constraint Scores (gnomAD)

```python
symbol = ids['symbol']

constraints = gnomad_get_gene_constraints(gene_symbol=symbol)

# Extract ALL 4 scores
if constraints:
    pli = constraints.get('pLI', 0)
    loeuf = constraints.get('LOEUF', 0)
    missense_z = constraints.get('missense_z', 0)
    prec = constraints.get('pRec', 0)
```

**REQUIRED**: All 4 constraint scores (pLI, LOEUF, missense Z, pRec).

### Clinical Variants

```python
# ClinVar
clinvar = clinvar_search_variants(gene=symbol)

# CIViC (cancer variants)
civic = civic_get_variants_by_gene(gene_symbol=symbol)

# cBioPortal (cancer mutations)
cbioportal = cBioPortal_get_mutations(gene_symbol=symbol)
```

---

## Phase 8: Disease Association Scoring (0-30 pts)

### Scoring Logic

```python
def score_disease_association(ids, ot_foundation, disease=None):
    scores = {'genetic': 0, 'literature': 0, 'pathway': 0, 'total': 0}
    evidence = []

    # Auto-discover if no disease provided
    if not disease:
        top_diseases = auto_discover_diseases(ot_foundation.get('diseases', {}), top_n=1)
        if top_diseases:
            disease = top_diseases[0]['name']

    # 1. Genetic Evidence (0-10)
    # GWAS (CRITICAL: uses `mapped_gene`, NOT `gene`)
    gwas = gwas_get_snps_for_gene(mapped_gene=ids['symbol'])
    if gwas and 'associations' in gwas:
        significant = [a for a in gwas['associations'] if a.get('pvalue', 1) < 5e-8]
        scores['genetic'] += min(len(significant) * 3, 6)
        if significant:
            evidence.append(f"GWAS: {len(significant)} significant loci [T3]")

    # Constraint scores
    constraints = gnomad_get_gene_constraints(gene_symbol=ids['symbol'])
    if constraints:
        pli = constraints.get('pLI', 0)
        if pli > 0.9:
            scores['genetic'] += 2
            evidence.append(f"pLI={pli:.2f} (highly constrained) [T3]")

    # 2. Literature Evidence (0-10)
    if disease:
        pubs = PubMed_search_articles(query=f"{ids['symbol']} AND {disease}", limit=200)
        count = len(pubs) if isinstance(pubs, list) else pubs.get('total', 0)

        if count > 100: scores['literature'] = 10
        elif count > 50: scores['literature'] = 7
        elif count > 10: scores['literature'] = 5
        elif count > 0: scores['literature'] = 3

        evidence.append(f"Literature: {count} publications [T4]")

    # 3. Pathway Evidence (0-10)
    diseases_data = ot_foundation.get('diseases', {})
    if isinstance(diseases_data, dict) and 'data' in diseases_data:
        for d in diseases_data['data']:
            if disease and disease.lower() in d.get('name', '').lower():
                score = d.get('associationScore', 0)
                if score > 0.8: scores['pathway'] = 10
                elif score > 0.5: scores['pathway'] = 7
                elif score > 0.2: scores['pathway'] = 4
                else: scores['pathway'] = 1
                evidence.append(f"OpenTargets score={score:.2f} [T3]")
                break

    scores['total'] = scores['genetic'] + scores['literature'] + scores['pathway']
    return {'scores': scores, 'evidence': evidence, 'disease': disease}
```

---

## Phase 9: Druggability Assessment (0-25 pts)

### Scoring Logic

```python
def score_druggability(ids, ot_foundation):
    scores = {'structural': 0, 'chemical': 0, 'target_class': 0, 'total': 0}
    evidence = []

    # 1. Structural Tractability (0-10)
    tractability = ot_foundation.get('tractability', {})
    sm_bucket = tractability.get('smallMolecule', {}).get('bucket', 0)

    if sm_bucket and sm_bucket <= 3:
        scores['structural'] = 10
    elif sm_bucket and sm_bucket <= 5:
        scores['structural'] = 7
    elif sm_bucket and sm_bucket <= 7:
        scores['structural'] = 5
    elif sm_bucket:
        scores['structural'] = 2

    if sm_bucket:
        evidence.append(f"SM tractability bucket: {sm_bucket} [T3]")

    # 2. Chemical Matter (0-10)
    chembl_id = ids.get('chembl_target')
    if chembl_id:
        activities = ChEMBL_get_target_activities(target_chembl_id__exact=chembl_id)
        # Handle response format
        if isinstance(activities, dict):
            compounds = activities.get('compounds', activities.get('data', []))
        else:
            compounds = activities if isinstance(activities, list) else []

        potent = [c for c in compounds if c.get('standard_value', 10000) < 100]
        if potent:
            scores['chemical'] = 10
            evidence.append(f"{len(potent)} compounds with IC50 < 100nM [T2]")
        elif compounds:
            scores['chemical'] = 7
            evidence.append(f"{len(compounds)} compounds in ChEMBL [T3]")

    # Fallback: BindingDB
    if scores['chemical'] < 10 and ids.get('uniprot'):
        ligands = BindingDB_get_ligands_by_uniprot(uniprot=ids['uniprot'], affinity_cutoff=1000)
        if ligands:
            scores['chemical'] = max(scores['chemical'], 7)
            evidence.append(f"BindingDB: {len(ligands)} ligands [T2]")

    # 3. Target Class Bonus (0-5)
    pharos = Pharos_get_target(gene=ids['symbol'])
    if pharos and 'tdl' in pharos:
        tdl = pharos['tdl']
        if tdl == 'Tclin':
            scores['target_class'] = 5
            evidence.append("Pharos TDL: Tclin [T1]")
        elif tdl == 'Tchem':
            scores['target_class'] = 4
            evidence.append("Pharos TDL: Tchem [T2]")
        elif tdl == 'Tbio':
            scores['target_class'] = 2
            evidence.append("Pharos TDL: Tbio [T3]")

    # GPCR/Kinase bonus
    if ids.get('is_gpcr'):
        scores['target_class'] = max(scores['target_class'], 5)
        evidence.append("GPCR target class [T1]")

    scores['total'] = scores['structural'] + scores['chemical'] + scores['target_class']
    return {'scores': scores, 'evidence': evidence}
```

---

## Phase 10: Safety Analysis (0-20 pts)

### Scoring Logic

```python
def score_safety(ids, ot_foundation):
    scores = {'expression': 0, 'genetic': 0, 'adverse': 0, 'total': 0}
    evidence = []
    safety_flags = []

    critical_tissues = ['heart', 'liver', 'kidney', 'brain', 'bone marrow']

    # 1. Expression Selectivity (0-5)
    gencode_id = ids.get('ensembl_versioned') or ids.get('ensembl')
    gtex = GTEx_get_median_gene_expression(gencode_id=gencode_id, operation="get_median_gene_expression")

    expression_in_critical = []
    if isinstance(gtex, dict) and 'data' in gtex:
        for tissue_data in gtex['data']:
            tissue = tissue_data.get('tissue', '').lower()
            tpm = tissue_data.get('median', 0)
            if any(c in tissue for c in critical_tissues) and tpm > 10:
                expression_in_critical.append(tissue)

    if not expression_in_critical:
        scores['expression'] = 5
        evidence.append("Low expression in critical tissues [T2]")
    elif len(expression_in_critical) == 1:
        scores['expression'] = 4
    else:
        scores['expression'] = 0
        safety_flags.append(f"High expression in: {', '.join(expression_in_critical)}")
        evidence.append(f"Expression in critical tissues: {expression_in_critical} [T2]")

    # 2. Genetic Validation (0-10)
    mouse_models = ot_foundation.get('mouse_models', {})
    if isinstance(mouse_models, dict) and 'data' in mouse_models:
        models = mouse_models['data']
        lethal = any('lethal' in str(m.get('phenotype_label', '')).lower() for m in models)

        if lethal:
            scores['genetic'] = 0
            safety_flags.append("Mouse KO lethal")
            evidence.append("Mouse KO: Lethal phenotype [T2]")
        elif models:
            scores['genetic'] = 7
            evidence.append("Mouse KO: Viable with phenotype [T2]")
        else:
            # Fall back to pLI
            constraints = gnomad_get_gene_constraints(gene_symbol=ids['symbol'])
            if constraints:
                pli = constraints.get('pLI', 0.5)
                if pli < 0.5:
                    scores['genetic'] = 5
                else:
                    scores['genetic'] = 2

    # 3. Known ADRs (0-5)
    safety_profile = ot_foundation.get('safety', {})
    if isinstance(safety_profile, dict) and 'data' in safety_profile:
        liabilities = safety_profile.get('data', [])
        severe = [l for l in liabilities if l.get('severity') == 'High']

        if not liabilities:
            scores['adverse'] = 5
            evidence.append("No known safety liabilities [T2]")
        elif severe:
            scores['adverse'] = 1
            safety_flags.append(f"Severe safety concerns: {len(severe)}")
        else:
            scores['adverse'] = 3

    scores['total'] = scores['expression'] + scores['genetic'] + scores['adverse']
    return {'scores': scores, 'evidence': evidence, 'safety_flags': safety_flags}
```

---

## Phase 11: Clinical Precedent (0-15 pts)

```python
def score_clinical_precedent(ot_foundation):
    drugs_data = ot_foundation.get('drugs', {})

    approved = []
    clinical = []

    if isinstance(drugs_data, dict) and 'data' in drugs_data:
        for drug in drugs_data['data']:
            phase = drug.get('phase', 0)
            if phase == 4:
                approved.append(drug)
            elif phase in [1, 2, 3]:
                clinical.append(drug)

    if approved:
        score = 15
        evidence = f"{len(approved)} FDA-approved drugs [T1]"
    elif any(d['phase'] == 3 for d in clinical):
        score = 10
        evidence = "Phase 3 clinical trials [T2]"
    elif any(d['phase'] == 2 for d in clinical):
        score = 7
        evidence = "Phase 2 clinical trials [T2]"
    elif clinical:
        score = 5
        evidence = "Phase 1 clinical trials [T2]"
    else:
        score = 0
        evidence = "No clinical development [T4]"

    return {'score': score, 'evidence': evidence, 'approved_drugs': approved[:5]}
```

---

## Phase 12: Validation Evidence (0-10 pts)

```python
def score_validation_evidence(ids, ot_foundation):
    scores = {'functional': 0, 'models': 0, 'total': 0}
    evidence = []

    # Check for CRISPR/DepMap data
    # Check for mouse model validation
    # Check for biochemical validation

    # Simplified: check mouse models
    mouse_models = ot_foundation.get('mouse_models', {})
    if isinstance(mouse_models, dict) and 'data' in mouse_models:
        models = mouse_models['data']
        if models:
            scores['functional'] = 3
            evidence.append("Mouse model data available [T2]")

    scores['total'] = scores['functional'] + scores['models']
    return {'scores': scores, 'evidence': evidence}
```

---

## Phase 13: Composite Scoring

### Priority Tiers

| Score | Tier | Recommendation |
|-------|------|----------------|
| 80-100 | Tier 1 | GO - Highly validated |
| 60-79 | Tier 2 | CONDITIONAL GO |
| 40-59 | Tier 3 | CAUTION |
| 0-39 | Tier 4 | NO-GO |

### Score Calculation

```python
total = (
    disease_scores['total'] +      # 0-30
    druggability_scores['total'] + # 0-25
    safety_scores['total'] +       # 0-20
    clinical_score +               # 0-15
    validation_scores['total']     # 0-10
)

if total >= 80: tier, rec = 1, "GO"
elif total >= 60: tier, rec = 2, "CONDITIONAL GO"
elif total >= 40: tier, rec = 3, "CAUTION"
else: tier, rec = 4, "NO-GO"
```

---

## Fallback Chains

When primary tools fail, try fallbacks in order:

| Primary | Fallback 1 | Fallback 2 | If All Fail |
|---------|------------|------------|-------------|
| `GTEx_get_median_gene_expression` | `HPA_get_comprehensive_gene_details` | `HPA_get_rna_expression_by_source` | Document unavailable |
| `ChEMBL_get_target_activities` | `BindingDB_get_ligands_by_uniprot` | `DGIdb_get_gene_druggability` | Note in report |
| `STRING_get_protein_interactions` | `intact_get_interactions` | `OpenTargets interactions` | Note in report |
| `Reactome_map_uniprot_to_pathways` | `OpenTargets GO` | `MyGene pathways` | Use GO only |
| `gnomad_get_gene_constraints` | `OpenTargets constraint` | - | Note unavailable |
| `PubMed_search_articles` | `EuropePMC_search_articles` | `PubTator3_LiteratureSearch` | Note in report |

**NEVER silently skip failed tools.** Document failures in Data Gaps section.

---

## Report Generation

Create file: `[TARGET]_validation_report.md`

### Required Sections

1. **Executive Summary** - Scorecard, tier, recommendation, key findings
2. **Part A: Target Intelligence** (7 sections)
   - Identifiers, Basic Info, Structure, Function, PPIs, Expression, Genetics
3. **Part B: Validation Assessment** (5 sections)
   - Disease Scoring, Druggability, Safety, Clinical, Validation
4. **Part C: Synthesis & Recommendations** (3 sections)
   - Composite Score, Validation Roadmap, Risks & Mitigations
5. **Appendices**
   - Data Sources, Completeness Checklist, Data Gaps, JSON Export

### ASCII Visualizations (REQUIRED)

```markdown
    VALIDATION SCORE BREAKDOWN
    ========================================
    Disease Association  [████████████████████] 28/30 (93%)
    Druggability         [████████████████████] 25/25 (100%)
    Safety Profile       [████████████        ] 12/20 (60%)
    Clinical Precedent   [████████████████████] 15/15 (100%)
    Validation Evidence  [████████████████████] 10/10 (100%)
    ========================================
    TOTAL: 90/100 | TIER 1 | RECOMMENDATION: GO


    TISSUE EXPRESSION HEATMAP
    ========================================
    Lung          [████████████████████] 120 | DISEASE-RELEVANT
    Liver         [████████████████    ]  96 | *CRITICAL*
    Kidney        [███████████         ]  68 | *CRITICAL*
    Heart         [████████            ]  48 | *CRITICAL*
    Brain         [████                ]  24 | *CRITICAL*
    ========================================
```

---

## Completeness Verification

Before finalizing report, verify ALL items:

### Data Minimums
- [ ] All identifiers resolved (UniProt, Ensembl, ChEMBL)
- [ ] Open Targets foundation queried (11 endpoints)
- [ ] PPIs: >= 10 interactors OR explanation
- [ ] Expression: Top 10 tissues with values OR explicit "unavailable"
- [ ] Diseases: Top 5 associations with scores
- [ ] Constraints: All 4 scores OR "unavailable"
- [ ] Druggability: Tractability + drugs + probes assessed

### Evidence Quality
- [ ] T1-T4 grades in Executive Summary
- [ ] T1-T4 grades in Disease Associations table
- [ ] All claims have source citations

### Negative Results
- [ ] Failed tools documented in Data Gaps
- [ ] Empty sections marked "Limited evidence" or "No data"
- [ ] Fallback tools tried when primary failed

---

## Reference Files

- [SCORING_CRITERIA.md](SCORING_CRITERIA.md) - Detailed scoring matrices
- [REPORT_TEMPLATE.md](REPORT_TEMPLATE.md) - Full report template
- [TOOL_REFERENCE.md](TOOL_REFERENCE.md) - Complete tool reference
- [EVIDENCE_GRADING.md](EVIDENCE_GRADING.md) - T1-T4 tier definitions
- [IMPLEMENTATION.md](IMPLEMENTATION.md) - Python code examples
- [EXAMPLES.md](EXAMPLES.md) - Worked examples (EGFR, KRAS, etc.)